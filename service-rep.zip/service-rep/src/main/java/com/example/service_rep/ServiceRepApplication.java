package com.example.service_rep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRepApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRepApplication.class, args);
	}

}
